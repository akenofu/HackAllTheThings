### Python
`python -m http.server 80`  
`python -m pyftpdlib -p 21 -w -d /tmp`
`ptftpd -p 69 -v eth0 /tmp`
`impacket-smbserver -username guest -password guest -smb2support share $(pwd)`
