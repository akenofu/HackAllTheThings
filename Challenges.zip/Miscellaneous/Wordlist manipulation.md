#### Password Mutation
`hashcat -m 0 bfield.hash /usr/share/wordlists/rockyou.txt -r rules`