TODO
- why are Named pipes used?
- Get premium access from client?
- wpfcommand?
- web attacks?


- Look into apk