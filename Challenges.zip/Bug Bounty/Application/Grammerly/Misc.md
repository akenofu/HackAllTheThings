Program Link:
[Grammarly - Bug Bounty Program | HackerOne](https://hackerone.com/grammarly?type=team)