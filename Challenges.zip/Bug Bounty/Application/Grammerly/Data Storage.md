- Where is user account data stored?
- Serialization vulnerabilities?


Notes:
`Grammarly.Auth.FSharp`  has DPAPI

Questions:
Where is data stored?
Where is serialized data coming 


#### Serialization ?
`Grammarly.Desktop.Services.Data::LoadConfigurationObjectFromFileOrDefault`

Pathes found
`C:\Users\karim\AppData\Local\Grammarly\DesktopIntegrations\Resources\Configuration\`
`C:\Users\karim\AppData\Roaming\Grammarly\DesktopIntegrations`


TODO
- Dig into newton soft

- Manipulate premium features??
`WaitForRedirectPipeMessage` pipes?
UserConfig Serialization?