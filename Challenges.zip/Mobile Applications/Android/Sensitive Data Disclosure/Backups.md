- Check AndroidManifest.xml to see if adb can take local backups, Check for `android:allowBackup` set to false, default is true, Note if device is encrypted backup is encryped too.

- Use [[adb Cheatsheet#Local Backups]] to navigate those backups