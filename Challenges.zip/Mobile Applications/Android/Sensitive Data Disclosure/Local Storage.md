### Check keywords/API calls that used to store data
- Keywords/Flags
`MODE_WORLD_READABLE` or `MODE_WORLD_WRITABLE`
- API calls
`SharedPreferences`
`FileOutPutStream`
`getExternal*`
`getWritableDatabase`
`getReadableDatabase`
`getCacheDir` or `getExternalCacheDirs`



