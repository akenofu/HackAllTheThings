- is Keyboard Cache Is Disabled for Text Input Fields
	```xml
	<EditText
	android:id="@+id/KeyBoardCache"
	android:inputType="textNoSuggestions" />
	```
