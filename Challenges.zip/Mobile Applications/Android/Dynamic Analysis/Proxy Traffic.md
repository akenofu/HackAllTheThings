####  Setup Burp
Configure Burp on computer
[Configuring an Android Device to Work With Burp - PortSwigger](https://portswigger.net/support/configuring-an-android-device-to-work-with-burp)
