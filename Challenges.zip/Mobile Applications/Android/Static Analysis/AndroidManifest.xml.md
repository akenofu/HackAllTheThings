### Determine Entry Point
Sorted by precedence (if possible)
1. Deeplinks with/out url schemes

2. LauncherActiviy

***

### Permissions  
- SD Card Storage
	```
	uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"
	```
***
