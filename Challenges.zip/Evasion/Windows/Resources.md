### Books

#### Win32 API

[Amazon.com: Windows 10 System Programming, Part 1 eBook: Yosifovich, Pavel: Kindle Store](https://www.amazon.com/Windows-10-System-Programming-Part-ebook/dp/B0871GTN2M)

[Windows 10 System… by Pavel Yosifovich \[PDF/iPad/Kindle\] (leanpub.com)](https://leanpub.com/windows10systemprogrammingpart2)

### Tools
[xforcered/Dendrobate: Managed code hooking template. (github.com)](https://github.com/xforcered/Dendrobate)

