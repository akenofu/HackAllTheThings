#### Static Analyzer tools
[presidentbeef/brakeman: A static analysis security vulnerability scanner for Ruby on Rails applications (github.com)](https://github.com/presidentbeef/brakeman)
