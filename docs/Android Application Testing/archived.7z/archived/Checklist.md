Crack Signing KeyStore
Crack Software backed Keystore
Shared-Library Sideloading