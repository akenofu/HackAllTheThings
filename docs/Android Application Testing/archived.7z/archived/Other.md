SideLoading Shared Libarires android
brute force keystore used to sign up android app
Hardware keystore