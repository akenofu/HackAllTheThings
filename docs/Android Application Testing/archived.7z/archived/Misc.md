### World Writable directories
- `/data/local/tmp/`