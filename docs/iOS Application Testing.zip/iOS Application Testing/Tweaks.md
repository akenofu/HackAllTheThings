# Tweaks
Add to Silea Repo's the following as sources:
```http
http://apt.thebigboss.org/repofiles/cydia/
https://cydia.ichitaso.com
http://repo.co.kr
https://ryleyangus.com/repo
```
## SSL Pinning Bypass
- SSL Kill Switch 2
## Jailbreak detection bypass
- A-Bypass
- Liberty Lite
- JailProtect
- HideJB
- KernBypass
## Management Tweaks
- Choicy
## Restart the SpringBoard from SSH
```bash
ssh root@192.168.114.153

killall -9 SpringBoard

# Not always needed, test the previous command first
reboot
```

