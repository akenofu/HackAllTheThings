# My Setup
iPhone 8, iOS 15.6 refuirbished from amazon. Jailbreak done using a Debian host.

1. Use 3u tools to install itunes
2. Enter DFU mode [How to Enter DFU Mode on iPhone - All Series Full Guide 2021](https://youtu.be/QXmrGvoSFkk?t=165) or [How to Get into DFU Mode on iPhone 8/8 Plus/X - EaseUS](https://mobi.easeus.com/ios-tips/how-to-get-into-dfu-mode-on-iphone-8-8-plus-x.html)
3. Jailbreak using [Installing palera1n | iOS Guide (cfw.guide)](https://ios.cfw.guide/installing-palera1n/)
4. If the Apple logo appears, the Side button was held down for too long. 
5. Exit DFU mode [How to Exit DFU Mode for iPhone 8 and Above](ttps://www.youtube.com/watch?v=OJoe0bjDxO8)



## Misc
- Disable auto locking the screen
- Disable click sounds