Before running this, make sure the iPhone is connected in VMWare's Removable devices settings. Double check the IPhone trusts the Linux VM. 
```bash
iproxy 2222 22

ssh root@127.0.0.1 -p 2222
```